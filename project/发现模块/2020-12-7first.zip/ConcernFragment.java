package com.riven.journey.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.riven.journey.R;
import com.riven.journey.adapter.recyclerAdapter.ConcernRecyclerAdapter;
import com.riven.journey.bean.Comments;
import com.riven.journey.bean.ConcernUser;
import com.riven.journey.util.ConfigUtil;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * @author 张硕
 */
public class ConcernFragment extends Fragment {
    private RecyclerView recyclerView;
    private View view;
    private Context mContext;
    private SmartRefreshLayout smartRefreshLayout;
    private ConcernRecyclerAdapter adapter;
    private int count = 0;

    private FragmentActivity activity;
    private List<ConcernUser> baseUsers = new ArrayList<>();
    public ConcernFragment(){}
    public ConcernFragment(FragmentActivity activity){
        this.activity = activity;
    }
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @SuppressLint("WrongConstant")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_found_concern,container,false);
        smartRefreshLayout = view.findViewById(R.id.refresh_concern);
        smartRefreshLayout.setEnableLoadMore(true);
        mContext = view.getContext();
        activity = getActivity();
        recyclerView = view.findViewById(R.id.rec_found_concern);
        adapter = new ConcernRecyclerAdapter(baseUsers,mContext,activity);

        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        manager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(manager);

        smartRefreshLayout.setEnableLoadMore(true);
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                smartRefreshLayout.autoRefresh();
            }
        });
        smartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                //网络输入流获取关注的对象
                initData();
                smartRefreshLayout.finishRefresh(500);
            }
        });
        smartRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener(){
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                smartRefreshLayout.finishLoadMore(500);
                initData();

            }
        });
        return view;
    }

    private void initData(){
        final String s = ConfigUtil.BASE_URL + "note/followInterface";
        String key = "?tel=1&count=" + count;
        count += 5;
        Request request = new Request.Builder().url(s+key).build();
        OkHttpClient okHttpClient = new OkHttpClient();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(mContext,"网络连接错误",Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String result = response.body().string();
                if(result.equals("1")){
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(mContext,"没有数据了哦",Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                try {
                    JSONObject jConcernUser = new JSONObject(result);
                    JSONArray jArray = jConcernUser.getJSONArray("array");
                    for (int i = 0;i<jArray.length();i++){
                        ConcernUser user = new ConcernUser();
                        JSONObject jUser = jArray.getJSONObject(i);
                        user.setUserName(jUser.getString("userName"));
                        user.setRelTime(jUser.getString("upload_time"));
                        user.setUserPhoto(jUser.getString("userHeadSrc"));
                        user.setFirstImg(jUser.getString("cover_src"));
                        user.setArtTitle(jUser.getString("titlle"));
                        user.setArtLike(jUser.getString("like_num"));
                        user.setArtColl(jUser.getString("collection_num"));
                        user.setIsLike(jUser.getString("isLove"));
                        user.setIsColl(jUser.getString("isCollection"));
                        user.setImgType(jUser.getString("res_type"));
                        if(!jUser.getString("nineSrc").equals("1")){
                            List<String> imgs = new ArrayList<>();
                            imgs.add(user.getFirstImg());
                            String[] imgUrls = jUser.getString("nineSrc").split(",");
                            for(int j=0;j<imgUrls.length;j++){
                                imgs.add(imgUrls[j]);
                            }
                            user.setImgUrls(imgs);
                        }else {
                            List<String> imgs = new ArrayList<>();
                            imgs.add(user.getFirstImg());
                            user.setImgUrls(imgs);
                        }
                        //分割评论
                        List<Comments> commentsList = new ArrayList<>();
                        String[] comments = jUser.getString("twoComments").split("&&&");
                        for(int j = 0;j<comments.length;j++){
                            Comments comt = new Comments();
                            String[] comts = comments[j].split("%%");
                            for (int f=0;f<comts.length;f++){
                                if(f==0){
                                    comt.setComUser(comts[0]);
                                }else if(f==1){
                                    comt.setComment(comts[1]);
                                }else if(f==2){
                                    comt.setComTime(comts[2]);
                                }
                            }
                            commentsList.add(comt);
                        }
                        user.setArtCom(commentsList);
                        user.setArtComCount(jUser.getString("comments_num"));
                        user.setArtId(jUser.getString("note_id"));
                        baseUsers.add(user);
                    }
                    Log.e("ConcernFragmentUserSize",baseUsers.size()+"");
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            LinearLayoutManager manager = new LinearLayoutManager(getContext());
                            manager.setOrientation(RecyclerView.VERTICAL);
                            recyclerView.setLayoutManager(manager);
                            recyclerView.setAdapter(adapter);
                        }
                    });

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }
}
