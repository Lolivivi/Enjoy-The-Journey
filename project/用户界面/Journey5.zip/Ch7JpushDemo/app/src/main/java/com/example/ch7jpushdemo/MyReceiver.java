package com.example.ch7jpushtest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import cn.jpush.android.api.CustomMessage;
import cn.jpush.android.api.NotificationMessage;
import cn.jpush.android.service.JPushMessageReceiver;

public class MyReceiver extends JPushMessageReceiver {

    /**
     * 收到自定义消息
     * @param context
     * @param customMessage
     */
    @Override
    public void onMessage(Context context, CustomMessage customMessage) {
        super.onMessage(context, customMessage);
        Log.i("lww", "收到自定义消息");
        String title = customMessage.title;
        String extra = customMessage.extra;
        String msg = customMessage.message;
        Log.i("lww", "自定义消息：" + title + "---" + extra + "---" + msg);
    }

    /**
     * 收到通知
     * @param context
     * @param notificationMessage
     */
    @Override
    public void onNotifyMessageArrived(Context context, NotificationMessage notificationMessage) {
        super.onNotifyMessageArrived(context, notificationMessage);
        Log.i("lww", "收到通知");
        String title = notificationMessage.notificationTitle;
        String content = notificationMessage.notificationContent;
        if(notificationMessage.isRichPush){
            Log.i("lww", "富文本通知消息");
            String path = notificationMessage._webPagePath;
            String appkey = notificationMessage.appkey;
            String extras= notificationMessage.notificationExtras;
            Log.i("lww", path + "---" + appkey + "---" + extras );
        }else{
            Log.i("lww", "普通通知消息");
        }
        Log.i("lww", title + "---" + content);
    }

    /**
     * 通知打开（点击）
     * @param context
     * @param notificationMessage
     */
    @Override
    public void onNotifyMessageOpened(Context context, NotificationMessage notificationMessage) {
        super.onNotifyMessageOpened(context, notificationMessage);
        Log.i("lww", "通知被点击");
    }
}
