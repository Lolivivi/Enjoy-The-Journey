package com.example.ch7jpushdemo;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import cn.jpush.android.service.JCommonService;

public class MyService extends JCommonService {
    public MyService() {
    }
}
