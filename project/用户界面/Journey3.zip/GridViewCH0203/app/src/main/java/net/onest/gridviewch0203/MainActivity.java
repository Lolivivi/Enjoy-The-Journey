package net.onest.gridviewch0203;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Student> studentList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initData();
        GridView gvStudent = findViewById(R.id.gv_student);
        CustomAdapter myAdapter = new CustomAdapter(this,
                studentList,
                R.layout.student_list_item);
        gvStudent.setAdapter(myAdapter);
        gvStudent.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //同ListView一样
            }
        });

        //初始化下拉列表
        initSpinner();
    }
    public void initData(){
        Student stu1 = new Student("张三","2018011785",R.drawable.boy);
        Student stu2 = new Student("李四","20180011786",R.drawable.girl);
        studentList.add(stu1);
        studentList.add(stu2);
    }

    public void initSpinner(){
        String[] citys = {"北京","上海","深圳"};
        ArrayAdapter myAdapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,
                citys);
        Spinner spCity = findViewById(R.id.sp_city);
        spCity.setAdapter(myAdapter);
    }
}
