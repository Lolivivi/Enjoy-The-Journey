package com.example.im777;

import android.content.Intent;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;

import com.hyphenate.easeui.domain.EaseUser;
import com.hyphenate.easeui.ui.EaseChatFragment;
import com.hyphenate.easeui.ui.EaseContactListFragment;
import com.hyphenate.easeui.ui.EaseConversationListFragment;
import com.hyphenate.easeui.widget.EaseContactList;

import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.concurrent.Callable;

import jp.wasabeef.glide.transformations.internal.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ConstactListFragment extends EaseContactListFragment {

    private ConstactListData constactListData;
    private Map<String,EaseUser> m = new HashMap<>();

    @Override
    protected void initView() {
        super.initView();
        //add loading view
        registerForContextMenu(listView);
    }



    @Override
    protected void setUpView() {
        super.setUpView();
        FormBody formBody = new FormBody.Builder()
                .build();
        Request request = new Request.Builder()
                .url("http://10.7.89.227:8080/journeyjourney/follow/showMyFollows?tel=1")
                .post(formBody)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("请求失败", "error");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String res = response.body().string();
                Log.e("res", res);
                String[] str = res.split("&&&");
                //tel数组手机号
                String[] tel = str[0].split(",");
                //img用户头像
                String[] img = str[1].split(",");
                for (int i = 0; i < tel.length; i++) {
                    if(tel[i].equals("")|| img[i].equals("")){
                        Log.e("null","该数据不能放进去");
                    }else{
                        String username = tel[i];
                        EaseUser user = new EaseUser(tel[i]);
                        user.setAvatar("http://10.7.89.227:8080/journeyjourney/"+img[i]);
                        m.put(username,user);
                    }
                }
                Log.e("m", m.toString());
                Message msg =handler.obtainMessage();
                msg.what=200;
                msg.obj=m;
                handler.sendMessage(msg);
            }
        });



        //设置联系人数据
        //Map<String, EaseUser> m = constactListData.getInstance().getConstacnList();
//                String res = response.body().string();
//                Log.e("res", res);
//                String[] str = res.split("&&&");
//                //tel数组手机号
//                String[] tel = str[0].split(",");
//                //img用户头像
//                String[] img = str[1].split(",");
//                for (int i = 0; i < tel.length; i++) {
//                    if(tel[i].equals("")|| img[i].equals("")){
//                        Log.e("null","该数据不能放进去");
//                    }else{
//                        String username = tel[i];
//                        EaseUser user = new EaseUser(tel[i]);
//                        user.setAvatar("http://10.7.89.227:8080/journeyjourney/"+img[i]);
//                        m.put(username,user);
//                    }
//                }
//                Log.e("m", m.toString());
//                Message msg =handler.obtainMessage();
//                msg.what=200;
//                msg.obj=m;
//                handler.sendMessage(msg);
//            }
//        });
//        if (m.equals("")){
//            Log.e("null","null");
//            return null;
//        }else{
//            return m;
//        }
//        Map<String, EaseUser> m = new HashMap<>();
//        String username = "123";
//        EaseUser user = new EaseUser(username);
//        user.setNickname("woshini");
//        user.setAvatar("https://img2.woyaogexing.com/2020/11/28/05fa02130a3f402fb37718e6a1e77356!400x400.jpeg");
//        m.put(username,user);

    }

//    public class Data implements Callable<Map<String,EaseUser>>{
//
//        @Override
//        public Map<String, EaseUser> call() throws Exception {
//            Map<String,EaseUser> map = new HashMap<>();
//
//            return map;
//        }
//    }
}
