package com.example.im777;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Message;
import android.util.Half;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.hyphenate.EMCallBack;
import com.hyphenate.chat.EMClient;
import com.hyphenate.chat.EMConversation;
import com.hyphenate.easeui.EaseConstant;
import com.hyphenate.easeui.domain.EaseUser;
import com.hyphenate.easeui.ui.EaseBaseActivity;
import com.hyphenate.easeui.ui.EaseContactListFragment;
import com.hyphenate.easeui.ui.EaseConversationListFragment;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class MainActivity1 extends EaseBaseActivity {
    private Button[] mTabs;
    //private EaseContactListFragment contactListFragment;
    private ConstactListFragment contactListFragment;
    private LikeFragment likeFragment;
    private Fragment[] fragments;
    private int index;
    private int currentTabIndex;
    private Button button;
    private EaseConversationListFragment conversationFragment;

    private ImageView message_img;
    private ImageView fans_img;
    private ImageView like_img;
    private SQLiteDatabase database;
    private Map<String, EaseUser> m = new HashMap<>();

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setContentView(R.layout.activity_main1);

        Myhelper myhelper = new Myhelper(this,"user.db",null,3);
        database = myhelper.getWritableDatabase();

        findViewById(R.id.query_data).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity1.this,QuerydataActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.delete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                database.execSQL("delete from user");
            }
        });

        findViewById(R.id.logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EMClient.getInstance().logout(false, new EMCallBack() {
                    @Override
                    public void onSuccess() {
                        Log.e("lgout","退出成功");
                        startActivity(new Intent(MainActivity1.this,LoginActivity.class));
                    }

                    @Override
                    public void onError(int i, String s) {
                        Log.e("logout","退出失败！");
                    }

                    @Override
                    public void onProgress(int i, String s) {

                    }
                });
            }
        });
        initview();
        conversationFragment = new EaseConversationListFragment();
        contactListFragment = new ConstactListFragment();
        likeFragment = new LikeFragment();
        fragments = new Fragment[]{conversationFragment,contactListFragment,likeFragment};
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_container,conversationFragment)
                .add(R.id.fragment_container,contactListFragment).hide(contactListFragment)
                .add(R.id.fragment_container,likeFragment).hide(likeFragment)
                .show(conversationFragment);

        conversationFragment.setConversationListItemClickListener(new EaseConversationListFragment.EaseConversationListItemClickListener() {
            @Override
            public void onListItemClicked(EMConversation conversation) {
                startActivity(new Intent(MainActivity1.this, ChatActivity.class).putExtra(EaseConstant.EXTRA_USER_ID, conversation.conversationId()));
            }
        });
        contactListFragment.setContactListItemClickListener(new EaseContactListFragment.EaseContactListItemClickListener() {

            @Override
            public void onListItemClicked(EaseUser user) {
                startActivity(new Intent(MainActivity1.this, ChatActivity.class).putExtra(EaseConstant.EXTRA_USER_ID, user.getUsername()));
            }
        });
    }

    private void initview(){
        mTabs = new Button[3];
        mTabs[0] = (Button) findViewById(R.id.btn_conversation);
        mTabs[1] = (Button) findViewById(R.id.btn_address_list);
        mTabs[2] = (Button) findViewById(R.id.btn_setting);
        // select first tab
        mTabs[0].setSelected(true);
    }

    @SuppressLint("ResourceAsColor")
    public void onTabClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_conversation:
                index = 0;
                mTabs[0].setTextColor(Color.WHITE);
                mTabs[1].setTextColor(Color.BLACK);
                mTabs[2].setTextColor(Color.BLACK);
                mTabs[0].setBackgroundColor(Color.BLACK);
                mTabs[1].setBackgroundColor(android.R.color.transparent);
                mTabs[2].setBackgroundColor(android.R.color.transparent);
                break;
            case R.id.btn_address_list:
                index = 1;
                mTabs[0].setTextColor(Color.BLACK);
                mTabs[1].setTextColor(Color.WHITE);
                mTabs[2].setTextColor(Color.BLACK);
                mTabs[1].setBackgroundColor(Color.BLACK);
                mTabs[0].setBackgroundColor(android.R.color.transparent);
                mTabs[2].setBackgroundColor(android.R.color.transparent);
                break;
            case R.id.btn_setting:
                index = 2;
                mTabs[0].setTextColor(Color.BLACK);
                mTabs[1].setTextColor(Color.BLACK);
                mTabs[2].setTextColor(Color.WHITE);
                mTabs[2].setBackgroundColor(Color.BLACK);
                mTabs[1].setBackgroundColor(android.R.color.transparent);
                mTabs[0].setBackgroundColor(android.R.color.transparent);
                break;
        }
        if (currentTabIndex != index) {
            FragmentTransaction trx = getSupportFragmentManager().beginTransaction();
            trx.hide(fragments[currentTabIndex]);
            if (!fragments[index].isAdded()) {
                trx.add(R.id.fragment_container, fragments[index]);
            }
            trx.show(fragments[index]).commit();
        }
        mTabs[currentTabIndex].setSelected(false);
        // set current tab selected
        mTabs[index].setSelected(true);
        currentTabIndex = index;
    }
}
