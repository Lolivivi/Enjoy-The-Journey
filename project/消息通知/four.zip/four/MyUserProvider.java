package com.example.im777;

import android.util.Log;

import com.hyphenate.easeui.EaseUI;
import com.hyphenate.easeui.domain.EaseUser;

import java.util.HashMap;
import java.util.Map;
import java.util.PropertyResourceBundle;

public class MyUserProvider implements EaseUI.EaseUserProfileProvider {

    private static MyUserProvider myUserProvider;

    private Map<String,EaseUser> userList = new HashMap<>();

    private ConstactListData constactListData;

    private String  url = "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1606638164827&di=0dab8b3d11ace48010417fae6bc6222c&imgtype=0&src=http%3A%2F%2Fww4.sinaimg.cn%2Fmw690%2F005uDj95ly1gf3tkyh9c8j30u00u1doo.jpg";


    @Override
    public EaseUser getUser(String username) {
        userList = constactListData.getInstance().getLikeList();
        userList = constactListData.getInstance().getConstacnList();
        if (userList.containsKey(username)){
            return userList.get(username);
        }
        Log.e("error,没有数据",username);
        return null;
    }

    public void setUser(String username,String nickname){
        if (!userList.containsKey(username)){
            EaseUser easeUser = new EaseUser(username);
        }
        EaseUser easeUser = getUser(username);

        easeUser.setNickname(nickname);
        easeUser.setAvatar(url+username);
    }

    private MyUserProvider(){
        Log.e("init","init");
    }

    public static MyUserProvider getInstance(){
        if (myUserProvider==null){
            myUserProvider=new MyUserProvider();
        }
        return myUserProvider;
    }
}
