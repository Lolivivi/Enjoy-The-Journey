package com.example.im777;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;

import com.hyphenate.easeui.domain.EaseUser;
import com.hyphenate.easeui.ui.EaseContactListFragment;
import com.hyphenate.easeui.widget.EaseContactList;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class LikeFragment extends EaseContactListFragment {

    @Override
    protected void initView() {
        super.initView();
        //add loading view
        registerForContextMenu(listView);
    }

    @Override
    public void refresh() {
        Map<String,EaseUser> m = ConstactListData.getInstance().getLikeList();
//        Map<String, EaseUser> m = new HashMap<>();
//        String username = "789";
//        String username1 ="aaa";
//        EaseUser user = new EaseUser(username);
//        EaseUser user1 = new EaseUser(username1);
//        m.put(username,user);
//        m.put(username1,user1);
        if (m instanceof Hashtable<?, ?>) {
            //noinspection unchecked
            m = (Map<String, EaseUser>) ((Hashtable<String, EaseUser>)m).clone();
        }
        setContactsMap(m);
        super.refresh();

    }

    @Override
    protected void setUpView() {
        super.setUpView();
        //喜欢
        //设置联系人数据
        Map<String, EaseUser> m = ConstactListData.getInstance().getLikeList();
//        Map<String, EaseUser> m = new HashMap<>();
//        String username = "123";
//        EaseUser user = new EaseUser(username);
//        user.setNickname("woshini");
//        user.setAvatar("13");
//        m.put(username,user);
        if (m instanceof Hashtable<?, ?>) {
            m = (Map<String, EaseUser>) ((Hashtable<String, EaseUser>)m).clone();
        }
        setContactsMap(m);
        super.setUpView();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                EaseUser user = (EaseUser)listView.getItemAtPosition(position);
                if (user != null) {
                    String username = user.getUsername();
                    // demo中直接进入聊天页面，实际一般是进入用户详情页
                    startActivity(new Intent(getActivity(), ChatActivity.class).putExtra("userId", username));
                }
            }
        });
    }
}
