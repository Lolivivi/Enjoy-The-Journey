package com.example.im777;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.hyphenate.easeui.domain.EaseUser;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Myhelper extends SQLiteOpenHelper {
    public Myhelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createSQL = "create table user(" +
                "tel text primary key," +
                "img text)";
        sqLiteDatabase.execSQL(createSQL);

        FormBody formBody = new FormBody.Builder()
                .build();
        Request request = new Request.Builder()
                .url("http://10.7.89.227:8080/journeyjourney/follow/showMyFollows?tel=1")
                .post(formBody)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("请求失败", "error");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String res = response.body().string();
                Log.e("res", res);
                String[] str = res.split("&&&");
                //tel数组手机号
                String[] tel = str[0].split(",");
                //img用户头像
                String[] img = str[1].split(",");
                for (int i = 0; i < tel.length; i++) {
                    if(tel[i].equals("")|| img[i].equals("")){
                        Log.e("null","该数据不能放进去");
                    }else{
                        ContentValues newdata = new ContentValues();
                        newdata.put("tel",tel[i]);
                        newdata.put("img","http://10.7.89.227:8080/journeyjourney/"+img[i]);
                        sqLiteDatabase.insert("user",null,newdata);
                    }
                }
            }
        });
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        Log.e("myhelper","helper");
    }
}
