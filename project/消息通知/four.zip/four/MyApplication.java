package com.example.im777;

import android.app.Application;
import android.util.Log;

import com.hyphenate.chat.EMClient;
import com.hyphenate.easeui.EaseUI;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        EaseUI.getInstance().init(this,null);
        Log.e("init","初始化成功!");
        EMClient.getInstance().setDebugMode(true);
        EaseUI.getInstance().setUserProfileProvider(MyUserProvider.getInstance());
    }
}
