package com.example.im777;


import android.os.Handler;
import android.os.Message;
import android.util.Log;

import androidx.annotation.NonNull;

import com.hyphenate.easeui.domain.EaseUser;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ConstactListData {

    private String url = "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1606638164827&di=0dab8b3d11ace48010417fae6bc6222c&imgtype=0&src=http%3A%2F%2Fww4.sinaimg.cn%2Fmw690%2F005uDj95ly1gf3tkyh9c8j30u00u1doo.jpg";
    static private ConstactListData ctld = new ConstactListData();

    public static ConstactListData getInstance(){

        if(ctld == null){
            ctld = new ConstactListData();
        }
        return ctld;
    }

    private Map<String, EaseUser> m = new HashMap<>();
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 200:
                    m = (Map<String, EaseUser>) msg.obj;
                    Log.e("data",m.toString());
                    break;
            }
        }
    };

    //喜欢列表

    public Map<String, EaseUser> getLikeList(){
//        Map<String, EaseUser> m = new HashMap<>();
//        String username1 = "1";
//        String username2 = "2";
//        String username3 = "3";
//        EaseUser user = new EaseUser(username1);
//        EaseUser user1 = new EaseUser(username2);
//        EaseUser user2 = new EaseUser(username3);
//        user.setAvatar(url);
//        user1.setAvatar(url);
//        user2.setAvatar(url);
//        m.put(username1,user);
//        m.put(username2,user1);
//        m.put(username3,user2);
        return m;
    }

    public Map<String,EaseUser> getConstacnList(){
//        Map<String, EaseUser> m = new HashMap<>();
//        EaseUser user = new EaseUser("189");
//        EaseUser user1 = new EaseUser("289");
//        EaseUser user2 = new EaseUser("389");
//        user.setAvatar("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1606638164827&di=0dab8b3d11ace48010417fae6bc6222c&imgtype=0&src=http%3A%2F%2Fww4.sinaimg.cn%2Fmw690%2F005uDj95ly1gf3tkyh9c8j30u00u1doo.jpg");
//        user1.setAvatar("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1606638164827&di=0dab8b3d11ace48010417fae6bc6222c&imgtype=0&src=http%3A%2F%2Fww4.sinaimg.cn%2Fmw690%2F005uDj95ly1gf3tkyh9c8j30u00u1doo.jpg");
//        user2.setAvatar("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1606638164827&di=0dab8b3d11ace48010417fae6bc6222c&imgtype=0&src=http%3A%2F%2Fww4.sinaimg.cn%2Fmw690%2F005uDj95ly1gf3tkyh9c8j30u00u1doo.jpg");
//        m.put("189",user);
//        m.put("289",user1);
//        m.put("389",user2);
//        return m;
        FormBody formBody = new FormBody.Builder()
                .build();
        Request request = new Request.Builder()
                .url("http://10.7.89.227:8080/journeyjourney/follow/showMyFollows?tel=1")
                .post(formBody)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("请求失败", "error");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String res = response.body().string();
                Log.e("res", res);
                String[] str = res.split("&&&");
                //tel数组手机号
                String[] tel = str[0].split(",");
                //img用户头像
                String[] img = str[1].split(",");
                for (int i = 0; i < tel.length; i++) {
                    if(tel[i].equals("")|| img[i].equals("")){
                        Log.e("null","该数据不能放进去");
                    }else{
                        String username = tel[i];
                        EaseUser user = new EaseUser(tel[i]);
                        //user.setAvatar("http://10.7.89.227:8080/journeyjourney/"+img[i]);
                        m.put(username,user);
                    }
                }
                Log.e("m", m.toString());
                Message msg =handler.obtainMessage();
                msg.what=200;
                msg.obj=m;
                handler.sendMessage(msg);
            }
        });
        if (m.equals("")){
            Log.e("null","null");
            return null;
        }else{
            return m;
        }
    }

    //粉丝列表
//    public Map<String, EaseUser> getConstactList() {
//        //Map<String, EaseUser> m = new HashMap<String,EaseUser>();
//        FormBody formBody = new FormBody.Builder()
//                .build();
//        Request request = new Request.Builder()
//                .url("http://10.7.89.227:8080/journeyjourney/follow/showMyFollows?tel=1")
//                .post(formBody)
//                .build();
//        OkHttpClient okHttpClient = new OkHttpClient();
//        Call call = okHttpClient.newCall(request);
//        call.enqueue(new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//                Log.e("请求失败", "error");
//            }
//
//            @Override
//            public void onResponse(Call call, Response response) throws IOException {
//                String res = response.body().string();
//                Log.e("res", res);
//                String[] str = res.split(",");
//                for (int i = 0; i < str.length; i++) {
//                    if(str[i].equals("")){
//                        Log.e("null","该数据不能放进去");
//                    }else{
//                        String username = str[i];
//                        EaseUser user = new EaseUser(str[i]);
//                        m.put(username,user);
//                    }
//                }
//                Log.e("m", m.toString());
//                Message msg =handler.obtainMessage();
//                msg.what=200;
//                msg.obj=m;
//                handler.sendMessage(msg);
//            }
//        });
//        Log.e("mapdata",m.toString());
//        if(m==null){
//            return null;
//        }else{
//            return m;
//        }
//    }

}

