package com.example.im777;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class QuerydataActivity extends AppCompatActivity {

    private SQLiteDatabase database;
    private List<User> users = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_querydata);
        Myhelper helper = new Myhelper(this,"user.db",null,3);
        database = helper.getWritableDatabase();
        getcontact();
        TextView textView = findViewById(R.id.text_img);
        textView.setText(users.toString());
    }

    public void getcontact(){
        Cursor cursor = database.rawQuery("select * from user",null);
//                Cursor cursor = database.query("user",
//                null, null, null,
//                null, null, null, null);
        if (cursor.moveToFirst()){
            do {
                User user = new User(cursor.getString(cursor.getColumnIndex("tel")),
                        cursor.getString(cursor.getColumnIndex("img")));
                users.add(user);

            }while (cursor.moveToNext());
            Log.e("data",users.toString());
        }
    }
}
