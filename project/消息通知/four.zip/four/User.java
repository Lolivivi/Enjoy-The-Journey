package com.example.im777;

public class User {
    private String username;
    private String imgview;

    public User(String username, String imgview) {
        this.username = username;
        this.imgview = imgview;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getImgview() {
        return imgview;
    }

    public void setImgview(String imgview) {
        this.imgview = imgview;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", imgview='" + imgview + '\'' +
                '}';
    }
}
