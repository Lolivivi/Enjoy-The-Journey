package com.example.im666;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.hyphenate.EMCallBack;
import com.hyphenate.chat.EMClient;
import com.hyphenate.exceptions.HyphenateException;

/*
登录界面
 */
public class LoginActivity extends AppCompatActivity {

    private EditText username;
    private EditText password;
    private Button res;
    private Button login;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        username =findViewById(R.id.username);
        password = findViewById(R.id.password);

        //登录
        findViewById(R.id.login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(username.getText().toString().equals("")|| password.getText().toString().equals("")){
                    Toast.makeText(LoginActivity.this,"输入不能为空",Toast.LENGTH_SHORT).show();
                }
                else {
                    EMClient.getInstance().login(username.getText().toString(), password.getText().toString(), new EMCallBack() {
                        @Override
                        public void onSuccess() {
                            SharedPreferences preferences =getSharedPreferences("sharename",MODE_PRIVATE);
                            SharedPreferences.Editor ed = preferences.edit();
                            ed.putString("userid",username.getText().toString());
                            ed.commit();
                            startActivity(new Intent(LoginActivity.this,MainActivity1.class));
                        }

                        @Override
                        public void onError(int i, String s) {
                            Looper.prepare();
                            Toast.makeText(LoginActivity.this,"登录失败",Toast.LENGTH_SHORT).show();
                            Looper.loop();
                        }

                        @Override
                        public void onProgress(int i, String s) {

                        }
                    });
                }
            }
        });

        //注册
        findViewById(R.id.res).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            EMClient.getInstance().createAccount(username.getText().toString(),password.getText().toString());
                            Log.e("res","注册成功");
                        } catch (HyphenateException e) {
                            e.printStackTrace();
                            Looper.prepare();
                            Toast.makeText(LoginActivity.this,"注册失败",Toast.LENGTH_SHORT).show();
                            Looper.loop();
                        }
                    }
                }).start();
            }
        });
    }
}
