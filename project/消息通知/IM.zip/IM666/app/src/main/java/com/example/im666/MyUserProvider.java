package com.example.im666;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import androidx.annotation.NonNull;

import com.hyphenate.easeui.EaseUI;
import com.hyphenate.easeui.domain.EaseUser;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/*
用户头像设置
 */
public class MyUserProvider implements EaseUI.EaseUserProfileProvider {

    private Context mcontext;
    private String userid;
    private static MyUserProvider myUserProvider;
    private Map<String, EaseUser> m = new HashMap<>();
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 200:
                    m = (Map<String, EaseUser>) msg.obj;
                    break;
            }
        }
    };


    private MyUserProvider(){
        Log.e("init","init");
    }

    public static MyUserProvider getInstance(){
        if (myUserProvider==null){
            myUserProvider=new MyUserProvider();
        }
        return myUserProvider;
    }


    @Override
    public EaseUser getUser(String username) {
        SharedPreferences preferences = mcontext.getSharedPreferences("sharename",Context.MODE_PRIVATE);
        userid = preferences.getString("userid","");
        m = initdata();
        if (m.containsKey(username)) {
            Log.e("username", username);
            return m.get(username);
        }
        Log.e("error,没有数据",username);
        return null;
    }

    private Map<String, EaseUser> initdata() {
        FormBody formBody = new FormBody.Builder()
                .build();
        Request request = new Request.Builder()
                .url("http://10.7.89.227:8080/journeyjourney/follow/showMyFollows?tel="+userid)
                .post(formBody)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("请求失败", "error");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String res = response.body().string();
                Log.e("res", res);
                if(!"0".equals(res)){
                    String[] str = res.split("&&&");
                    //tel数组手机号
                    String[] tel = str[0].split(",");
                    //img用户头像
                    String[] img = str[1].split(",");
                    //用户名
                    String[] name = str[2].split(",");
                    for (int i = 0; i < tel.length; i++) {
                        if("".equals(tel[i])|| "".equals(img[i])||"".equals(name[i])){
                            Log.e("null","该数据不能放进去");
                        }else{
                            String username = name[i];
                            EaseUser user = new EaseUser(name[i]);
                            user.setAvatar(Utils.imgip+img[i]);
                            m.put(username,user);
                        }
                    }
                    Log.e("m", m.toString());
                    Message msg =handler.obtainMessage();
                    msg.what=200;
                    msg.obj=m;
                    handler.sendMessage(msg);
                }
            }
        });
        return m;
    }
}
