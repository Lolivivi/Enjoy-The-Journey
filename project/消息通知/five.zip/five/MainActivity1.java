package com.example.im666;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.FragmentTransaction;

import com.hyphenate.EMCallBack;
import com.hyphenate.chat.EMClient;
import com.hyphenate.chat.EMConversation;
import com.hyphenate.easeui.EaseConstant;
import com.hyphenate.easeui.ui.EaseBaseActivity;

import com.hyphenate.easeui.ui.EaseConversationListFragment;
import com.roughike.bottombar.BottomBar;
import com.roughike.bottombar.OnTabSelectListener;
/*
主页面
 */

public class MainActivity1 extends EaseBaseActivity {
    private ConstactListFragment contactListFragment;
    private LikeFragment likeFragment;
    private EaseConversationListFragment conversationFragment;
    private TextView text;
    private ImageView logout;


    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setContentView(R.layout.activity_main1);

        text = findViewById(R.id.text);
        //退出登录
        logout = findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EMClient.getInstance().logout(false, new EMCallBack() {
                    @Override
                    public void onSuccess() {
                        startActivity(new Intent(MainActivity1.this,LoginActivity.class));
                    }

                    @Override
                    public void onError(int i, String s) {
                        Log.e("logout","退出失败");
                    }

                    @Override
                    public void onProgress(int i, String s) {

                    }
                });
            }
        });

        //导航栏
        BottomBar bottomBar = findViewById(R.id.bottomBar);
        bottomBar.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelected(int tabId) {
                switch (tabId){
                    case R.id.tab_favorites:
                        conversationfragment();
                        text.setText("全部私信");
                        conversationFragment.setConversationListItemClickListener(new EaseConversationListFragment.EaseConversationListItemClickListener() {
                            @Override
                            public void onListItemClicked(EMConversation conversation) {
                                startActivity(new Intent(MainActivity1.this,ChatActivity.class).putExtra(EaseConstant.EXTRA_USER_ID,conversation.conversationId()));
                            }
                        });
                        break;
                    case R.id.tab_nearby:
                        contactListfragment();
                        text.setText("我的粉丝");
                        break;
                    case R.id.tab_friends:
                        likefragment();
                        text.setText("喜欢我的");
                        break;
                }
            }
        });

    }
    //会话列表
    private void conversationfragment(){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if(conversationFragment==null){
            conversationFragment = new EaseConversationListFragment();
            transaction.add(R.id.contentContainer,conversationFragment);
        }
        transaction.setCustomAnimations(
                R.anim.slide_right_in,
                R.anim.slide_left_out,
                R.anim.slide_left_in,
                R.anim.slide_right_out
        );
        hideFragment(transaction);
        transaction.show(conversationFragment);
        transaction.commit();
    }

    //联系人列表
    private void contactListfragment(){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if(contactListFragment==null){
            contactListFragment = new ConstactListFragment();
            transaction.add(R.id.contentContainer,contactListFragment);
        }
        transaction.setCustomAnimations(
                R.anim.slide_right_in,
                R.anim.slide_left_out,
                R.anim.slide_left_in,
                R.anim.slide_right_out
        );
        hideFragment(transaction);
        transaction.show(contactListFragment);
        transaction.commit();
    }

    //喜欢我的列表
    private void likefragment(){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if (likeFragment==null){
            likeFragment = new LikeFragment();
            transaction.add(R.id.contentContainer,likeFragment);
        }
        transaction.setCustomAnimations(
                R.anim.slide_right_in,
                R.anim.slide_left_out,
                R.anim.slide_left_in,
                R.anim.slide_right_out
        );
        hideFragment(transaction);
        transaction.show(likeFragment);
        transaction.commit();
    }

    //隐藏fragment
    private void hideFragment(FragmentTransaction transaction){
        if (contactListFragment!=null){
            transaction.hide(contactListFragment);
        }
        if (conversationFragment!=null){
            transaction.hide(conversationFragment);
        }
        if (likeFragment!=null){
            transaction.hide(likeFragment);
        }
        if (likeFragment !=null){
            transaction.hide(likeFragment);
        }
    }
}