package com.example.im666;

import java.util.Map;

public class Utils {
    //img的ip地址
    public static String imgip = "http://10.7.89.227:8080/journeyjourney/";
}
