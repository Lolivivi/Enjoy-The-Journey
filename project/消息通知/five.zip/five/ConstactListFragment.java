package com.example.im666;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;

import com.google.gson.internal.$Gson$Preconditions;
import com.hyphenate.easeui.domain.EaseUser;
import com.hyphenate.easeui.ui.EaseContactListFragment;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
/*
粉丝列表界面
 */
public class ConstactListFragment extends EaseContactListFragment {

    private Map<String, EaseUser> m = new HashMap<>();
    private String userid;

    @Override
    protected void initView() {
        super.initView();
        //add loading view
        registerForContextMenu(listView);
        SharedPreferences preferences = getActivity().getSharedPreferences("sharename", Context.MODE_PRIVATE);
        userid = preferences.getString("userid","");

    }

    public class MyThread extends Thread {
        @Override
        public void run() {
            super.run();
            try {
                URL url = new URL("http://10.7.89.227:8080/journeyjourney/follow/showMyFollows?tel="+userid);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                InputStream in = connection.getInputStream();
                int len = 0;
                byte[] bytes = new byte[1024];
                String res = "";
                while ((len = in.read(bytes)) != -1) {
                    res = res + new String(bytes, 0, len, "UTF-8");
                }
                if (!"0".equals(res)){
                    String[] str = res.split("&&&");
                    //tel数组手机号
                    String[] tel = str[0].split(",");
                    //img用户头像
                    String[] img = str[1].split(",");
                    //用户名
                    String[] name = str[2].split(",");
                    for (int i = 0; i < tel.length; i++) {
                        if ("".equals(tel[i]) || "".equals(name[i])||"".equals(img[i])) {
                            Log.e("null", "该数据不能放进去");
                        } else {
                            String username = name[i];
                            EaseUser user = new EaseUser(name[i]);
                            user.setAvatar(Utils.imgip + img[i]);
                            m.put(username, user);
                        }
                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Log.e("12344566",m.toString());
        }
    }

    //刷新
    @Override
    public void refresh() throws InterruptedException {
        super.refresh();
//        m = initdata();
        MyThread myThread = new MyThread();
        myThread.start();
        Thread.currentThread().join(1000/25);
        if (m instanceof Hashtable<?, ?>) {
            //noinspection unchecked
            m = (Map<String, EaseUser>) ((Hashtable<String, EaseUser>) m).clone();
        }
        setContactsMap(m);
    }


    //获取粉丝列表展示
    @Override
    protected void setUpView() throws InterruptedException {
//        m = initdata();
        MyThread myThread = new MyThread();
        myThread.start();
        Thread.currentThread().join(1000/25);
        if (m instanceof Hashtable<?, ?>) {
            m = (Map<String, EaseUser>) ((Hashtable<String, EaseUser>) m).clone();
        }
        setContactsMap(m);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                EaseUser user = (EaseUser) listView.getItemAtPosition(position);
                if (user != null) {
                    String username = user.getUsername();
                    // demo中直接进入聊天页面，实际一般是进入用户详情页
                    startActivity(new Intent(getActivity(), ChatActivity.class).putExtra("userId", username));
                }
            }
        });
        super.setUpView();
    }
}

