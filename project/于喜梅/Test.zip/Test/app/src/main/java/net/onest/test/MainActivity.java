package net.onest.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<String> urls;
    private RecyclerView recyclerView;
    private ImageView ivHeadImg;//头像
    private TextView tvUserName;//昵称
    private Button btnFollow;//关注
    private Button btnNote;//发布者作品按钮
    private TextView tvTitle;//笔记标题
    private Button btnTag;//笔记标签
    private TextView tvText;//笔记内容
    private EditText edtComments;//编辑评论
    private Button btnLove;//点赞
    private TextView tvLoveCount;//点赞数
    private Button btnCollection;//收藏
    private TextView tvCollectionCount;//点赞数
    private Button btnComments;//评论
    private TextView tvCommentsCount;//点赞数
    private int followClick;//点击关注按钮的次数
    private int loveClick;//点击点赞按钮的次数
    private int collectionClick;//点击收藏按钮的次数
    private int loveCount;//点赞数
    private int collectionCount;//被收藏数
    private int commentsCount;//评论数
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //获取控件
        getViews();
        //设置监听器
        setListener();
        //初始化九图
        setRecycler();
        //设置发布者的头像，昵称
        String path=getFilesDir().getAbsoluteFile()+"/a1.jpg";
        Glide.with(this).load(path).circleCrop().into(ivHeadImg);
        tvUserName.setText("倾听她的事");
        //设置笔记标题
        tvTitle.setText("生活需要一杯美好");
        //设置笔记标签
        //设置笔记内容
        tvText.setText("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        //设置点赞数
        tvLoveCount.setText(loveCount+"");
        //设置被收藏数
        tvCollectionCount.setText(collectionCount+"");
        //设置评论数
        tvCommentsCount.setText(commentsCount+"");
    }

    /*
        设置监听器
     */
    private void setListener() {
        MyListener myListener=new MyListener();
        //关注按钮
        btnFollow.setOnClickListener(myListener);
        //作品按钮控件
        btnNote.setOnClickListener(myListener);
        //点赞
        btnLove.setOnClickListener(myListener);
        //收藏
        btnCollection.setOnClickListener(myListener);
    }

    /*
        获取控件
     */
    private void getViews() {
        ivHeadImg=findViewById(R.id.iv_headImg);
        tvUserName=findViewById(R.id.tv_userName);
        btnNote=findViewById(R.id.btn_note);
        tvTitle=findViewById(R.id.tv_title);
        btnFollow=findViewById(R.id.btn_follow);
        btnTag=findViewById(R.id.btn_tag);
        tvText=findViewById(R.id.tv_text);
        edtComments=findViewById(R.id.edt_comments);
        btnLove=findViewById(R.id.btn_love);
        tvLoveCount=findViewById(R.id.tv_love_count);
        btnCollection=findViewById(R.id.btn_collection);
        tvCollectionCount=findViewById(R.id.tv_collection_count);
        btnComments=findViewById(R.id.btn_comments);
        tvCommentsCount=findViewById(R.id.tv_comments_count);
    }

    /*
        初始化九图
     */
    private void setRecycler() {
        initData();
        recyclerView=findViewById(R.id.cusom_swipe_view);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(1,StaggeredGridLayoutManager.HORIZONTAL));
        recyclerView.setAdapter(new ConcernImgRecyclerAdapter(urls,getApplicationContext()));
        new PagerSnapHelper().attachToRecyclerView(recyclerView);
    }


    //提供九图的数据源
    private void initData() {
        urls=new ArrayList<String>();
        String path1=getFilesDir().getAbsoluteFile()+"/a1.jpg";
        urls.add(path1);
        String path2=getFilesDir().getAbsoluteFile()+"/a2.jpg";
        urls.add(path2);
        String path3=getFilesDir().getAbsoluteFile()+"/a3.jpg";
        urls.add(path3);
    }

    /*
        内部类
     */
    class MyListener implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btn_follow:
                    followClick+=1;
                    if(followClick%2==1){
                        //关注
                        btnFollow.setBackgroundResource(R.drawable.input_bg2);
                        btnFollow.setText("已关注");
                        btnFollow.setTextColor(getResources().getColor(R.color.myDarkGray));
                    }else{
                        //取消关注
                        //弹出对话框
                        AlertDialog.Builder adBuilder
                                = new AlertDialog.Builder(MainActivity.this);
                        adBuilder.setMessage("确定不再关注");
                        adBuilder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                btnFollow.setBackgroundResource(R.drawable.input_bg3);
                                btnFollow.setText("+关注");
                                btnFollow.setTextColor(getResources().getColor(R.color.myRed));
                            }
                        });
                        adBuilder.setNegativeButton("取消", new DialogInterface.OnClickListener(){

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //关注
                                followClick-=1;
                                btnFollow.setBackgroundResource(R.drawable.input_bg2);
                                btnFollow.setText("已关注");
                                btnFollow.setTextColor(getResources().getColor(R.color.myDarkGray));
                            }
                        });
                        AlertDialog ad = adBuilder.create( );
                        ad.show( );
                    }
                    break;
                case R.id.btn_note:
                    Intent intent1=new Intent(MainActivity.this,NotesActivity.class);
                    startActivity(intent1);
                    break;
                case R.id.btn_love:
                    //点赞
                    loveClick+=1;
                    if(loveClick%2==1){
                        //点赞
                        //更换背景图片
                        btnLove.setBackgroundResource(R.drawable.ic_like1);
                        //修改点赞数
                        loveCount+=1;
                        //向服务端传送数据
                    }else{
                        //取消点赞
                        //更换背景图片
                        btnLove.setBackgroundResource(R.drawable.ic_like0);
                        //修改评论数
                        loveCount-=1;
                        //向服务端传送数据
                    }
                    break;
                case R.id.btn_collection:
                    //收藏
                    collectionClick+=1;
                    if(collectionClick%2==1){
                        //收藏
                        btnCollection.setBackgroundResource(R.mipmap.ic_collection1);
                    }else {
                        //取消收藏
                        btnCollection.setBackgroundResource(R.mipmap.ic_collection0);
                    }
                    break;
                case R.id.btn_comments:
                    //翻看评论
                    //向服务端获取数据
                    break;
            }
        }
    }
}
