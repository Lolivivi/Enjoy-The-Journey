package net.onest.test;

public class ConfigUtil {
    public static String BASE_URL = "http://10.7.89.227:8080/journeyjourney/";
}
